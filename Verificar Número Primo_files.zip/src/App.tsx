
function App() {
  return (
        <div className="flex w-full h-screen items-center justify-center flex-col space-y-3 p-2">
            <span className="loader" />
            <div className="text-base font-semibold">
                Writing your code for you! Your preview will appear here soon.
            </div>
        </div>
    );


}
export default App;
